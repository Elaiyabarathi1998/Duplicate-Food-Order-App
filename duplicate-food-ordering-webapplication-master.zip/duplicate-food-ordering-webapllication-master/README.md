# Zomato-Clone[MERN-STACK]
Project is developed using MVC architecture
Built a dynamic and responsive Web Application where user can easily interact and make their request done.
Functionalities that have been included:
1)A user can log in or sign up using his social media accounts like Google Login.
2)Filter,search,sort,high cost,low cost,cusine,Payment Integration.
